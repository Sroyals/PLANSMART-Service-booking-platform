// import React, { useEffect, useState } from 'react';
// import '../static/Invoice.css';
// import { Link } from 'react-router-dom';

// const Invoice = () => {
//   const [serviceDetails, setServiceDetails] = useState([]);
//   const [total, setTotal] = useState(0);

//   useEffect(() => {
//     // Fetch service details from local storage
//     const storedDetails = JSON.parse(localStorage.getItem('serviceDetails'));
//     if (storedDetails) {
//       setServiceDetails(storedDetails);
//     }
//   }, []);

//   useEffect(() => {
//     // Calculate total charges, GST, and final total
//     const calculateTotal = () => {
//       let serviceTotal = 0;
//       const charges = serviceDetails.map((service) => {
//         serviceTotal += parseFloat(service.amount.replace(/,/g, ''));
//         return { item: service.item, amount: service.amount };
//       });

//       const gstCharge = (serviceTotal * 0.3).toFixed(2);
//       const portalCharge = 700;

//       const totalAmount = serviceTotal + parseFloat(gstCharge) + portalCharge;
//       setTotal(totalAmount);

//       setServiceDetails([
//         ...charges,
//         { item: 'GST (30%)', amount: `${gstCharge}/-` },
//         { item: 'Portal Charge', amount: `${portalCharge}/-` },
//       ]);
//     };

//     calculateTotal();
//   }, [serviceDetails]);

//   const handleClose = () => {
//     window.close();
//   };

//   return (
//     <div className="invoice-container">
//       <span className="close-button" onClick={handleClose}>×</span>
//       <h2>YOUR INVOICE</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>Item</th>
//             <th>Amount</th>
//           </tr>
//         </thead>
//         <tbody>
//           {serviceDetails.map((row, index) => (
//             <tr key={index}>
//               <td>{row.item}</td>
//               <td>{row.amount}</td>
//             </tr>
//           ))}
//           <tr>
//             <th className="total">Total</th>
//             <td className="total">{total.toLocaleString()}/-</td>
//           </tr>
//         </tbody>
//       </table>
//       <Link to="/payment"><button>BOOK NOW</button></Link>
//     </div>
//   );
// };

// export default Invoice;



// import React, { useEffect, useState } from 'react';
// import '../static/Invoice.css';
// import { Link, useLocation } from 'react-router-dom';

// const Invoice = () => {
//   const location = useLocation();
//   const [serviceDetails, setServiceDetails] = useState([]);
//   const [total, setTotal] = useState(0);

//   useEffect(() => {
//     const vendorDetails = location.state?.vendorDetails;
//     console.log(vendorDetails);

//     if (vendorDetails) {
//       setServiceDetails([{ item: vendorDetails.name, amount: vendorDetails.price }]);
//     }
//   }, [location.state]);

//   useEffect(() => {
//     const calculateTotal = () => {
//       let serviceTotal = 0;

//       // Safely parse and sum service amounts
//       serviceDetails.forEach((service) => {
//         const amount = typeof service.amount === 'string'
//           ? parseFloat(service.amount.replace(/,/g, ''))
//           : service.amount;

//         serviceTotal += amount || 0; // Fallback to 0 if amount is undefined or NaN
//       });

//       // Calculate GST and portal charges
//       const gstCharge = (serviceTotal * 0.3).toFixed(2); // 30% GST
//       const portalCharge = 700;
//       const totalAmount = serviceTotal + parseFloat(gstCharge) + portalCharge;
//       setTotal(totalAmount);

//       // Add GST and portal charges if not already in `serviceDetails`
//       const additionalCharges = [
//         { item: 'GST (30%)', amount: `${gstCharge}/-` },
//         { item: 'Portal Charge', amount: `${portalCharge}/-` },
//       ];

//       if (!serviceDetails.some((service) => service.item === 'GST (30%)')) {
//         setServiceDetails((prevDetails) => [...prevDetails, ...additionalCharges]);
//       }
//     };

//     if (serviceDetails.length > 0) {
//       calculateTotal();
//     }
//   }, [serviceDetails]);

//   const handleClose = () => {
//     window.close();
//   };

//   return (
//     <div className="invoice-container">
//       <span className="close-button" onClick={handleClose}>×</span>
//       <h2>YOUR INVOICE</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>Item</th>
//             <th>Amount</th>
//           </tr>
//         </thead>
//         <tbody>
//           {serviceDetails.map((row, index) => (
//             <tr key={index}>
//               <td>{row.item}</td>
//               <td>{row.amount}</td>
//             </tr>
//           ))}
//           <tr>
//             <th className="total">Total</th>
//             <td className="total">{total.toLocaleString()}/-</td>
//           </tr>
//         </tbody>
//       </table>
//       <Link to="/payment"><button>BOOK NOW</button></Link>
//     </div>
//   );
// };

// export default Invoice;

import React, { useEffect, useState } from 'react';
import '../static/Invoice.css';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { API_BASE_URL } from '../configurations/config';

const Invoice = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [serviceDetails, setServiceDetails] = useState([]);
  const [total, setTotal] = useState(0);
  const [gstCharge, setGstCharge] = useState(0);
  const portalCharge = 700; // Fixed portal charge
  const orderDetails=location.state?.orderdetails
  // Fetch service details on component mount
  useEffect(() => {
    const vendorDetails = location.state?.vendorDetails;
    
    if (vendorDetails) {
      setServiceDetails([{id:vendorDetails.service_id, item: vendorDetails.name, amount: vendorDetails.price }]);
    }
  }, [location.state]);

  // Calculate total, GST, and portal charges
  useEffect(() => {
    const calculateTotal = () => {
      let serviceTotal = 0;

      // Sum service amounts safely
      serviceDetails.forEach((service) => {
        const amount = typeof service.amount === 'string'
          ? parseFloat(service.amount.replace(/,/g, ''))
          : service.amount;
        serviceTotal += amount || 0;
      });

      // Calculate GST (30% of service total)
      const calculatedGstCharge = (serviceTotal * 0.3).toFixed(2);
      setGstCharge(parseFloat(calculatedGstCharge));

      // Calculate final total
      const totalAmount = serviceTotal + parseFloat(calculatedGstCharge) + portalCharge;
      setTotal(totalAmount);
    };

    if (serviceDetails.length > 0) {
      calculateTotal();
    }
  }, [serviceDetails]);

  const handleOrderCreation = async () => {
    const orderAddress = JSON.parse(localStorage.getItem('order_address'));
    const user = JSON.parse(localStorage.getItem('user'));

    if (!orderAddress || !user) {
      alert("Order address or user information is missing.");
      return;
    }

    console.log(serviceDetails);
    
    // Prepare order payload with service IDs only
    const orderData = {
      user_id: user.user.user_uid,
      address: orderAddress.address,
      state: orderAddress.state,
      city_town: orderAddress.city_town,
      pincode: orderAddress.pincode,
      date_time: orderAddress.date,
      services: serviceDetails.map((service) => ({ service_uid: service.id })), // Map to service IDs
      total_amount: total,
      request:orderDetails
    };
    
    // Store the initial orderData in localStorage
    localStorage.setItem('order', JSON.stringify(orderData));
    
    console.log(orderData);
    
    // Uncomment to enable order submission
    try {
      const response = await fetch(`${API_BASE_URL}/order/${user.user.user_uid}/place`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData),
      });
    
      if (response.status === 201) {
        const responseData = await response.json(); // Parse the response as JSON
        const order_uid = responseData.order_uid; // Extract the order_uid from the response
    
        // Add order_uid to orderData
        orderData.order_uid = order_uid;
    
        // Update localStorage with the modified orderData
        localStorage.setItem('order', JSON.stringify(orderData));
    
        alert("Order created successfully!");
        navigate('/payment'); // Redirect to home page
      }
    } catch (error) {
      console.error("Error creating order:", error);
      alert("There was an error creating your order.");
    }
  };

  const handleClose = () => {
    window.close();
  };

  return (
    <div className="invoice-container">
      <span className="close-button" onClick={handleClose}>×</span>
      <h2>YOUR INVOICE</h2>
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          {serviceDetails.map((row, index) => (
            <tr key={index}>
              <td>{row.item}</td>
              <td>{row.amount}</td>
            </tr>
          ))}
          <tr>
            <td>GST (30%)</td>
            <td>{gstCharge.toLocaleString()}/-</td>
          </tr>
          <tr>
            <td>Portal Charge</td>
            <td>{portalCharge.toLocaleString()}/-</td>
          </tr>
          <tr>
            <th className="total">Total</th>
            <td className="total">{total.toLocaleString()}/-</td>
          </tr>
        </tbody>
      </table>
      <button onClick={handleOrderCreation}>BOOK NOW</button>
    </div>
  );
};

export default Invoice;
