function Footer(){
    return(
        <footer>Footer Component 
            <p>&copy; {new Date().getFullYear()} Subhradip Palit</p>
        </footer>
    );
}

export default Footer