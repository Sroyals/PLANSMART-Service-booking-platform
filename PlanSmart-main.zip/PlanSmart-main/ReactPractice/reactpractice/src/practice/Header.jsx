function Header(){
    return(
        <header>Header Component</header>
    );
}

export default Header